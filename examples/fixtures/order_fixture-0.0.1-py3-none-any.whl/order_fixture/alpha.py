from . import registry
registry.append("alpha")
