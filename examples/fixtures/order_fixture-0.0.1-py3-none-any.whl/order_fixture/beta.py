from . import registry
registry.append("beta")
