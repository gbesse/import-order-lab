import json,sys
from . import registry
print(json.dumps({"order":registry},sort_keys=True))
sys.exit(0 if registry==["alpha","beta"] else 1)
